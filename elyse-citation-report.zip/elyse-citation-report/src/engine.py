"""
engine.py — Runs a query against a live-retrieval answer engine.

Uses the Anthropic Messages API with the server-side web_search tool. That
combination is a reasonable proxy for what ChatGPT Search, Perplexity and
Google AI Mode do: retrieve, synthesise, cite. What we care about is not the
prose — it is which URLs came back and whether the brand survived the
synthesis step.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, asdict
from urllib.parse import urlparse

from anthropic import Anthropic

from .config import DEFAULT_MODEL, MAX_SEARCHES_PER_QUERY

# Deliberately neutral. We are not trying to coax the engine into a good
# answer — we want the answer a buyer would actually get.
SYSTEM_PROMPT = (
    "You are a web-connected assistant answering a consumer's real estate "
    "question. Search the web for current information before answering. "
    "Be specific: name buildings, prices, developers, and timelines where "
    "you can verify them. If you are unsure of a detail, say so rather than "
    "guessing. Answer in 200-400 words."
)


@dataclass
class Source:
    url: str
    title: str
    domain: str


@dataclass
class EngineResponse:
    query_id: str
    query_text: str
    stage: str
    pillar: str
    answer: str
    sources: list[dict]
    search_queries: list[str]
    model: str
    error: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def _domain(url: str) -> str:
    try:
        host = urlparse(url).netloc.lower()
        return host[4:] if host.startswith("www.") else host
    except Exception:
        return ""


def _extract(content_blocks) -> tuple[str, list[Source], list[str]]:
    """Pull answer text, cited sources, and the engine's own search terms."""
    text_parts: list[str] = []
    sources: dict[str, Source] = {}
    searches: list[str] = []

    for block in content_blocks:
        btype = getattr(block, "type", None)

        if btype == "text":
            text_parts.append(block.text)
            # Inline citations attached to the text — the strongest signal,
            # because these are sources the model actually leaned on.
            for cite in (getattr(block, "citations", None) or []):
                url = getattr(cite, "url", None)
                if url and url not in sources:
                    sources[url] = Source(
                        url=url,
                        title=getattr(cite, "title", "") or "",
                        domain=_domain(url),
                    )

        elif btype == "server_tool_use":
            q = (getattr(block, "input", {}) or {}).get("query")
            if q:
                searches.append(q)

        elif btype == "web_search_tool_result":
            # Everything the engine retrieved, cited or not. Useful for
            # spotting near-misses: you were retrieved but not used.
            for result in (getattr(block, "content", None) or []):
                url = getattr(result, "url", None)
                if url and url not in sources:
                    sources[url] = Source(
                        url=url,
                        title=getattr(result, "title", "") or "",
                        domain=_domain(url),
                    )

    return "".join(text_parts), list(sources.values()), searches


def ask(client: Anthropic, query: dict, model: str = DEFAULT_MODEL,
        retries: int = 2) -> EngineResponse:
    """Run one query. Returns an EngineResponse even on failure."""
    last_err = None

    for attempt in range(retries + 1):
        try:
            msg = client.messages.create(
                model=model,
                max_tokens=1600,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": query["text"]}],
                tools=[{
                    "type": "web_search_20250305",
                    "name": "web_search",
                    "max_uses": MAX_SEARCHES_PER_QUERY,
                }],
            )
            answer, sources, searches = _extract(msg.content)
            return EngineResponse(
                query_id=query["id"],
                query_text=query["text"],
                stage=query.get("stage", "unclassified"),
                pillar=query.get("pillar", ""),
                answer=answer,
                sources=[asdict(s) for s in sources],
                search_queries=searches,
                model=model,
            )
        except Exception as exc:  # noqa: BLE001 — we want the run to continue
            last_err = str(exc)
            if attempt < retries:
                time.sleep(2 ** attempt * 3)

    return EngineResponse(
        query_id=query["id"],
        query_text=query["text"],
        stage=query.get("stage", "unclassified"),
        pillar=query.get("pillar", ""),
        answer="",
        sources=[],
        search_queries=[],
        model=model,
        error=last_err,
    )
