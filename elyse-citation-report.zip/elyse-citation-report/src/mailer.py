"""
mailer.py — Sends the report via Gmail SMTP.

Requires a Google App Password, not your account password. Google disabled
plain password SMTP; an App Password is a 16-character token generated at
myaccount.google.com/apppasswords with 2-Step Verification switched on.
"""

from __future__ import annotations

import smtplib
from email.message import EmailMessage
from pathlib import Path


def send_report(
    *,
    gmail_address: str,
    app_password: str,
    recipients: list[str],
    subject: str,
    html_body: str,
    text_body: str,
    attachments: list[Path] | None = None,
) -> None:
    msg = EmailMessage()
    msg["From"] = f"Elyse Buckhead Reporting <{gmail_address}>"
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = subject
    msg.set_content(text_body)
    msg.add_alternative(html_body, subtype="html")

    for path in attachments or []:
        data = Path(path).read_bytes()
        msg.add_attachment(
            data,
            maintype="text",
            subtype="markdown" if str(path).endswith(".md") else "plain",
            filename=Path(path).name,
        )

    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=60) as smtp:
        smtp.login(gmail_address, app_password)
        smtp.send_message(msg)
