"""Configuration loading for the Elyse Buckhead citation report."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
CONFIG_DIR = ROOT / "config"
DATA_DIR = ROOT / "data"
REPORTS_DIR = ROOT / "reports"

# Model used to stand in for a live answer engine. Configurable so you can
# re-baseline without touching code.
DEFAULT_MODEL = os.getenv("CITATION_MODEL", "claude-sonnet-5")

# How many web searches the engine may run per query. Higher = more realistic
# retrieval, more tokens, slower run.
MAX_SEARCHES_PER_QUERY = int(os.getenv("MAX_SEARCHES_PER_QUERY", "4"))


@dataclass
class BrandConfig:
    raw: dict
    name: str
    aliases: list[str]
    owned_domains: list[str]
    partner_domains: list[str]
    competitors: list[dict]
    facts: list[dict]
    tone: dict
    scoring: dict = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path | None = None) -> "BrandConfig":
        path = path or CONFIG_DIR / "brand.yaml"
        raw = yaml.safe_load(path.read_text())
        brand = raw["brand"]
        comps = [
            c for c in raw.get("competitors", [])
            if c.get("treat_as_competitor", True)
        ]
        return cls(
            raw=raw,
            name=brand["name"],
            aliases=brand.get("aliases", [brand["name"]]),
            owned_domains=raw.get("owned_domains", []),
            partner_domains=raw.get("partner_domains", []),
            competitors=comps,
            facts=raw.get("facts", []),
            tone=raw.get("tone", {}),
            scoring=raw.get("scoring", {}),
        )


def load_queries(path: Path | None = None) -> list[dict]:
    path = path or CONFIG_DIR / "queries.yaml"
    return yaml.safe_load(path.read_text())["queries"]


def require_env(name: str) -> str:
    val = os.getenv(name)
    if not val:
        raise SystemExit(
            f"Missing required environment variable: {name}\n"
            f"Set it locally in .env, or as a GitHub Actions secret."
        )
    return val
